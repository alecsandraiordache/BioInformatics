from collections import Counter

S = "TACGTGCGCGCGAGCTATCTACTGACTTACGACTAGTGTAGCTGCATCATCGATCGA".strip().upper()
n = len(S)

def count_kmers(seq, k):
    counts = Counter()
    for i in range(len(seq) - k + 1):
        kmer = seq[i:i+k]
        counts[kmer] += 1
    return counts

dinucleotide_counts = count_kmers(S, 2)
trinucleotide_counts = count_kmers(S, 3)

total_dinucleotide = n - 1
total_trinucleotide = n - 2

print(f"Sequence length: {n}")
print(f"Total dinucleotide windows: {total_dinucleotide}")
print(f"Total trinucleotide windows: {total_trinucleotide}\n")

print("Dinucleotides found in sequence:")
for k, v in dinucleotide_counts.items():
    print(f"{k}: {v} - {v/total_dinucleotide*100:.2f}%")

print("\nTrinucleotides found in sequence:")
for k, v in trinucleotide_counts.items():
    print(f"{k}: {v} - {v/total_trinucleotide*100:.2f}%")
