import tkinter as tk
from tkinter import filedialog, messagebox
import matplotlib.pyplot as plt

# -------- FASTA I/O --------
def read_fasta(file_path: str) -> str:
    """Read the first sequence from a FASTA-like file."""
    with open(file_path, "r") as f:
        lines = f.readlines()
    seq = "".join(line.strip() for line in lines if not line.startswith(">"))
    return seq.upper()

# ---- Sliding-window relative frequencies (in PERCENT) ----
def sliding_window_frequencies(seq: str, window_size: int = 30):
    """Compute relative frequency (%) for A, C, G, T only."""
    symbols = ["A", "C", "G", "T"]
    positions = []
    freqs = {s: [] for s in symbols}

    # Remove all characters except A/C/G/T
    seq = "".join([s for s in seq if s in symbols])
    if len(seq) < window_size:
        raise ValueError("Sequence too short or contains no A/C/G/T characters.")

    for i in range(len(seq) - window_size + 1):
        window = seq[i:i + window_size]
        total = len(window)
        for s in symbols:
            value = (window.count(s) / total) * 100 if total else 0.0
            freqs[s].append(value)
        positions.append(i + window_size // 2)
    return positions, freqs

# -------- GUI action --------
def open_and_analyze():
    file_path = filedialog.askopenfilename(
        title="Select FASTA file",
        filetypes=[("FASTA files", "*.fasta *.fa *.faa"), ("All files", "*.*")]
    )
    if not file_path:
        return

    try:
        seq = read_fasta(file_path)
        positions, freqs = sliding_window_frequencies(seq, window_size=30)

        plt.figure(figsize=(10, 6))
        for s in ["A", "C", "G", "T"]:
            plt.plot(positions, freqs[s], label=s, linewidth=2)
        plt.title("DNA Relative Frequencies (%) — Sliding Window = 30")
        plt.xlabel("Sequence Position")
        plt.ylabel("Relative Frequency (%)")
        plt.ylim(0, 100)
        plt.yticks([0, 25, 50, 75, 100])
        plt.legend()
        plt.grid(True, linestyle="--", alpha=0.6)
        plt.tight_layout()
        plt.show()

    except Exception as e:
        messagebox.showerror("Error", f"An error occurred:\n{e}")

# -------- GUI --------
root = tk.Tk()
root.title("DNA Sliding Window Analyzer")

tk.Label(root, text="Select a FASTA file to analyze", font=("Arial", 12)).pack(pady=10)
tk.Button(
    root,
    text="Open FASTA File",
    command=open_and_analyze,
    width=25,
    height=2,
    bg="lightblue",
).pack(pady=20)

root.mainloop()
